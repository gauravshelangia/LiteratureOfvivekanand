package com.vivekanand.literature.literatureofvivekanand.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.vivekanand.literature.literatureofvivekanand.R;

/**
 * Created by rounak on 23/2/18.
 */

public class CardAdapter extends ArrayAdapter<Integer> {

    public CardAdapter (Context context, int resource) {
        super(context, resource);
    }

    @NonNull
    @Override
    public View getView(int position, View convertview,ViewGroup parent){
        ImageView imgView = (ImageView) convertview.findViewById(R.id.bengali_content);
        imgView.setImageResource(getItem(position));
        return convertview;
    }

}

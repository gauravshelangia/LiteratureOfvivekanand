package com.vivekanand.literature.literatureofvivekanand;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.vivekanand.literature.literatureofvivekanand.R;
import com.vivekanand.literature.literatureofvivekanand.adapter.CardAdapter;
import com.vivekanand.literature.literatureofvivekanand.sharedPreference.SharedPreferenceLoader;
import com.wenchao.cardstack.CardStack;

public class bengali extends AppCompatActivity implements CardStack.CardEventListener {
    private CardStack card_stack;
    private CardAdapter card_adapter;


    private SharedPreferenceLoader sharedPreferenceLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        sharedPreferenceLoader = new SharedPreferenceLoader(this);
        if (sharedPreferenceLoader.loadNightMode()) {
            setTheme(R.style.AppThemeNight);
        } else {
            setTheme(R.style.AppThemeDay);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.books_list);
        initImage();

        card_stack = (CardStack) findViewById(R.id.card_stack);
        card_stack.setContentResource(R.layout.bengali);
        card_stack.setStackMargin(20);
        card_stack.setAdapter(card_adapter);

        card_stack.setListener(this);
    }

    private void initImage() {
        card_adapter = new CardAdapter(getApplicationContext(), 0);
        card_adapter.add(R.drawable.photo1);
        card_adapter.add(R.drawable.photo2);
        card_adapter.add(R.drawable.photo3);
        card_adapter.add(R.drawable.photo4);

    }

    @Override
    public boolean swipeEnd(int i, float v) {
        return (v>300)?true:false;
    }

    @Override
    public boolean swipeStart(int i, float v) {
        return false;
    }

    @Override
    public boolean swipeContinue(int i, float v, float v1) {
        return false;
    }

    @Override
    public void discarded(int i, int i1) {

    }

    @Override
    public void topCardTapped() {

    }
}